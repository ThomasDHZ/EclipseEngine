#include "MaterialManager.h"

std::shared_ptr<Material> MaterialManager::DefaultMaterial;
std::vector<std::shared_ptr<Material>> MaterialManager::MaterialList;